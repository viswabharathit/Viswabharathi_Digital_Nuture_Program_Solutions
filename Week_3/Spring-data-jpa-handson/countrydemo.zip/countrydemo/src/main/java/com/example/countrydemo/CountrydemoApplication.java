package com.example.countrydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountrydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountrydemoApplication.class, args);
	}

}
