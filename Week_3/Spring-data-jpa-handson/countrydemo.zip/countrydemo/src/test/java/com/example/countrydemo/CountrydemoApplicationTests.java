package com.example.countrydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountrydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
